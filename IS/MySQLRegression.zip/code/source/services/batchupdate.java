package services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-08-20 15:03:25 IST
// -----( ON-HOST: VMSUBB02W.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class batchupdate

{
	// ---( internal utility methods )---

	final static batchupdate _instance = new batchupdate();

	static batchupdate _newInstance() { return new batchupdate(); }

	static batchupdate _cast(Object o) { return (batchupdate)o; }

	// ---( server methods )---




	public static final void populateInput (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(populateInput)>> ---
		// @sigtype java 3.5
		// [o] record:1:required inputs
		// [o] - field:0:required varchar_col
		// [o] - object:0:required tinyint_col
		// [o] - field:0:required text_col
		// [o] - object:0:required smallint_col
		// [o] - object:0:required mediumint_col
		// [o] - object:0:required int_col
		// [o] - object:0:required bigint_col
		// [o] - object:0:required float_col
		// [o] - object:0:required double_col
		// [o] - object:0:required decimal_col
		// [o] - field:0:required char_col
		// [o] - field:0:required tinytext_col
		// [o] - field:0:required mediumtext_col
		// [o] - field:0:required longtext_col
		// [o] - field:0:required enum_col
		// [o] - field:0:required set_col
		// [o] - object:0:required bool_col
		int start = 1;
		IData [] T_row = new IData[10];
		int intData=800;
		double dData=800.7; 
		String charData="updated";
		for (int i = start; i <=10; i++)
		{	
			Object orow[][] = {
					{"varchar_col", charData},
					{"tinyint_col", i},
					{"text_col", charData},
					{"smallint_col", i},
					{"mediumint_col", intData+i},
					{"int_col_col", intData+i},
					{"bigint_col", intData+i},
					{"float_col", 1999F},
					{"double_col", dData},
					{"decimal_col", dData},
					{"char_col", charData},
					{"tinytext_col", charData},
					{"mediumtext_col", charData},
					{"longtext_col", charData},
					{"enum_col", new String("2")},
					{"set_col", new String("2")},
					{"bool_col", true}
			};
			T_row[i-start] = (IData)new Values(orow);
		}
		ValuesEmulator.put(pipeline,"inputs",T_row);
		// --- <<IS-END>> ---

                
	}
}

