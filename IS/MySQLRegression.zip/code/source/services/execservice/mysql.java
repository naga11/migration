package services.execservice;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-08-20 15:22:24 IST
// -----( ON-HOST: VMSUBB02W.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.Connection;
import java.sql.SQLException;
// --- <<IS-END-IMPORTS>> ---

public final class mysql

{
	// ---( internal utility methods )---

	final static mysql _instance = new mysql();

	static mysql _newInstance() { return new mysql(); }

	static mysql _cast(Object o) { return (mysql)o; }

	// ---( server methods )---




	public static final void insertRecord (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(insertRecord)>> ---
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor();
		Connection connection = (Connection)IDataUtil.get(pipelineCursor,"$db_service_connection");
		String sql = new String("insert into testtable values (12,'Home')");
		try
		{
			connection.createStatement().execute(sql);
		}
		catch (SQLException e)
		{
			throw new ServiceException(e);
		}
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void testConnection (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(testConnection)>> ---
		// @sigtype java 3.5
		java.sql.Connection conn = (java.sql.Connection) IDataUtil.get(
				pipeline.getCursor(), "$db_service_connection"); 
		try {
			java.sql.PreparedStatement pstmt = conn
					.prepareStatement("insert into testtable values(1,'Chris')");
			pstmt.execute();
		} catch (Throwable e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
		// --- <<IS-END>> ---

                
	}



	public static final void updateRecord (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(updateRecord)>> ---
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor(); 
		Connection connection = (Connection)IDataUtil.get(pipelineCursor,"$db_service_connection");
		String sql = new String("update testtable set description ='Houseupdated'");
		try
		{
			connection.createStatement().execute(sql);
		}
		catch (SQLException e)
		{
			throw new ServiceException(e);
		}
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void useConnection (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(useConnection)>> ---
		// @sigtype java 3.5
		// [i] object:0:required $db_service_connection
		// [i] record:0:required Employee
		// [i] - object:0:required ID
		// [i] - field:0:required Name
		// [o] record:0:required Customer
		// [o] - object:0:required CID
		// [o] - field:0:required CName
		// [o] - record:0:required CPermAddress
		// [o] -- field:0:required House
		// [o] -- object:0:required Street
		// [o] - record:1:required COtherAddress
		// [o] -- field:0:required House
		// [o] -- object:0:required Street
		IDataCursor pipelineCursor = pipeline.getCursor();
		Connection connection = (Connection)IDataUtil.get(pipelineCursor,"$db_service_connection");
		IData PermAddress = (IData)IDataUtil.get(pipelineCursor, "PermAddress");
		String House = IDataUtil.get(PermAddress.getCursor(), "House").toString();
		Integer Street = (Integer)IDataUtil.get(PermAddress.getCursor(), "Street");
		String sql = new String("insert into testtable values  (" + Street.intValue() + ",'" + House + "')");
		try
		{
			connection.createStatement().execute(sql);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		int start = 1, count=2;
		IData [] otherAddress = new IData[count];
		
		for (int i = start; i <= count; i++)
		{	
			Object orow[][] = {{"House", new String("Peace Home")},
				{"Street", new Integer(i)}};
			otherAddress[i-start] = (IData)new Values(orow);
		}
		
		Object permAddress[][] = {{"House", new String("Peace")},
				{"Street", new Integer(11)}};
		Object employee[][] = {{"CID", new Integer(1)}, 
			{"CName", new String("Bose")}, 
			{"CPermAddress",(IData)new Values(permAddress)},
			{"COtherAddress",otherAddress}};
		IDataUtil.put(pipelineCursor,"Customer",(IData)new Values(employee));
		//Remove the Name from Pipeline
		IDataUtil.remove(pipelineCursor,"Name");
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

