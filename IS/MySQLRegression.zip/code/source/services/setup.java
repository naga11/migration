package services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-08-20 15:08:17 IST
// -----( ON-HOST: VMSUBB02W.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.IOException;
import java.io.InputStream;
// --- <<IS-END-IMPORTS>> ---

public final class setup

{
	// ---( internal utility methods )---

	final static setup _instance = new setup();

	static setup _newInstance() { return new setup(); }

	static setup _cast(Object o) { return (setup)o; }

	// ---( server methods )---




	public static final void getBLOBsize (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBLOBsize)>> ---
		// @sigtype java 3.5
		// [i] object:0:required InputStream
		// [o] object:0:required blobSize
		IDataCursor pipelineCursor = pipeline.getCursor();
		Object object = IDataUtil.get(pipelineCursor,"InputStream");
		InputStream inputStream = (InputStream)IDataUtil.get(pipelineCursor,"InputStream");
		Long blobSize; 
		try
		{
			long bytesRead = 0;
			while (inputStream.read() != -1)
			{
				bytesRead++;
			}
			   
			inputStream.close();
			blobSize = new Long(bytesRead);
		}
		catch (IOException e)
		{
			throw new ServiceException(e);
		}
		pipelineCursor.insertAfter("blobSize", blobSize);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

