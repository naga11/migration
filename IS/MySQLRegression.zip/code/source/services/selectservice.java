package services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-08-20 14:55:45 IST
// -----( ON-HOST: VMSUBB02W.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
// --- <<IS-END-IMPORTS>> ---

public final class selectservice

{
	// ---( internal utility methods )---

	final static selectservice _instance = new selectservice();

	static selectservice _newInstance() { return new selectservice(); }

	static selectservice _cast(Object o) { return (selectservice)o; }

	// ---( server methods )---




	public static final void DataProvider (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(DataProvider)>> ---
		// @sigtype java 3.5
		// [o] object:0:required exampledate
		// [o] object:0:required exampleblob
		// [o] object:0:required examplebyte
		// [o] object:0:required exampleyear
		// [o] object:0:required exampleblob1
		byte[] bytes = new byte[] { 20, 40, -123, 89, 56, 100, 34 };
		try { 
			Blob blb = new SerialBlob(bytes);
			Date d = new Date(new java.util.Date().getTime());
			Object d1 = "2012";
			ValuesEmulator.put(pipeline, "exampledate", d);
			ValuesEmulator.put(pipeline, "exampleblob", blb);
			ValuesEmulator.put(pipeline, "examplebyte", bytes);
			ValuesEmulator.put(pipeline, "exampleyear", d1);
			byte[] bytes1 = new String("Blob Column Values").getBytes();
			ValuesEmulator.put(pipeline, "exampleblob1", bytes1);
		} catch (SerialException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// --- <<IS-END>> ---

                
	}
}

